<?php
  //creating connection to database
  $con=mysqli_connect("localhost","root","","polisi") or die(mysqli_error());

  //check whether submit button is pressed or not
if((isset($_POST['submit'])))
{
 //fetching and storing the form data in variables
 $nama = $con->real_escape_string($_POST['name']);
 $nik = $con->real_escape_string($_POST['NIK']);
 $nohp = $con->real_escape_string($_POST['phone']);
 $pesan = $con->real_escape_string($_POST['message']);
 $gambar = $con->real_escape_string($_POST['gambar']);
   //query to insert the variable data into the database
$sql="INSERT INTO laporan (nama, nik, nohp, pesan, gambar) VALUES ('".$nama."','".$nik."', '".$nohp."', '".$pesan."', '".$gambar."')";
 
  //Execute the query and returning a message
  if(!$result = $con->query($sql)){
    die('Error occured [' . $con->error . ']');
    }
    else
       echo "Thank you! We will get in touch with you soon";
}
?>